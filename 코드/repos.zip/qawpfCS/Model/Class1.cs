﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace qawpfCS.Model
{
    public class ChatRecord
    {
        public string USER_ID { get; set; }
        public string CHAT_RECORD { get; set; }
        public string CHAT_TIMESTAMP { get; set; }
    }

}
